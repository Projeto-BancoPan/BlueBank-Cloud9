package com.bancopna.cloud9.bluebank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BluebankApplicationTests {

	@Test
	void contextLoads() {
	}

}
